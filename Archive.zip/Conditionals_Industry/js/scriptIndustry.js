// Devante Webb 12/11/2014 Industry Conditionals

alert("Please tell me about your progress today.");
var gameSales = Number(prompt("How many games have you sold today?"));
var systemSales = Number(prompt("How many gaming systems have you sold today?"));
var gameProducts = Number(prompt("How much non-gaming merch have you sold today?"));
var today = prompt("What day is today? \n Sun, Mon, Tue, Wed, Thu, Fri, Sat:");

if( today == "Sun" || systemSales >= 4 || gameSales >= 24 ){
    alert("Sales today are great, please continue");
}
if(gameProducts > gameSales && gameSales < 24 && systemSales < 3){
    alert("excellent work selling the non-game merch")
}
(gameSales < 24 && systemSales < 3) ? alert("sales are low, please upsale products" : alert("Sales are steady today");
//: alert("Please upsell non-gaming Merchandise");
